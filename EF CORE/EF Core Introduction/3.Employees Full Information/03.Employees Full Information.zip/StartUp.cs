﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var dbcontext = new SoftUniContext();
            Console.WriteLine(GetEmployeesFullInformation(dbcontext));
        }
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                 .Select(e => new { e.EmployeeId, e.FirstName, e.MiddleName, e.LastName, e.JobTitle, e.Salary })
                 .OrderBy(e => e.EmployeeId).ToList();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
            }
            return sb.ToString();
        }
    }
}
