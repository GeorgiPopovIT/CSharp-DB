﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var dbcontext = new SoftUniContext();
            Console.WriteLine(GetEmployeesWithSalaryOver50000(dbcontext));
        }
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees.Select(employee =>
            new { employee.FirstName, employee.Salary })
                .Where(employee => employee.Salary > 50000)
                .OrderBy(employee => employee.FirstName).ToList();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }
    }
}
