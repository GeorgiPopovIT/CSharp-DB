﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var dbcontext = new SoftUniContext();
            Console.WriteLine(GetEmployeesFromResearchAndDevelopment(dbcontext));
        }
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees
                .Select(e => new { e.FirstName, e.LastName, e.Salary, e.Department.Name })
                .Where(e => e.Name == "Research and Development")
                .OrderBy(e => e.Salary).ThenByDescending(e => e.FirstName);
               
               

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from Research and Development - ${employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }
    }
}
